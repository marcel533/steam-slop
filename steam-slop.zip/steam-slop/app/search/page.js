'use client'
import Link from 'next/link'
import { Suspense, useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { useLang } from '@/lib/i18n'
import { Cover, SearchBar } from '@/components/ui'

function Results() {
  const q = (useSearchParams().get('q') ?? '').slice(0, 64)
  const { t } = useLang()
  const [list, setList] = useState(undefined)
  useEffect(() => {
    let live = true
    setList(undefined)
    fetch(`/api/search?q=${encodeURIComponent(q)}&limit=12`).then((r) => (r.ok ? r.json() : [])).then((d) => live && setList(d)).catch(() => live && setList([]))
    return () => { live = false }
  }, [q])
  return (
    <section>
      <div className="mb-6"><SearchBar /></div>
      <h1 className="mb-4 text-2xl font-semibold tracking-tight">{t('resultsFor')}: <span className="text-accent">{q}</span></h1>
      {list === undefined && <p className="text-white/50" role="status">{t('loading')}</p>}
      {list && list.length === 0 && <p className="text-white/70">{t('noResults')}</p>}
      {list && list.length > 0 && (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((g) => (
            <li key={g.id}>
              <Link href={`/game/${g.id}`} className="block overflow-hidden rounded-lg border border-white/[0.08] bg-surface transition-colors hover:border-accent">
                <Cover game={g} className="aspect-[460/215] w-full" />
                <div className="p-3"><h2 className="font-medium leading-snug">{g.name}</h2><p className="text-sm text-white/50">{g.dev}{g.dev && g.date ? ', ' : ''}{g.date}</p></div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}
export default function Page() { return <Suspense fallback={null}><Results /></Suspense> }
