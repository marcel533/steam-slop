'use client'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { useEffect, useState } from 'react'
import { AlertTriangle, ArrowLeft, BarChart3, CheckCircle2, ExternalLink, Scale, FileSearch, Newspaper, PlayCircle, Tag, Users } from 'lucide-react'
import { CommunityAi, CopyLink, MyVerdict, WatchButton } from '@/components/community'
import { remember } from '@/lib/recent'
import { SteamButton } from '@/components/brand'
import { useLang } from '@/lib/i18n'
import { getGame } from '@/lib/games'
import { Bar, Cover, SlopMeter } from '@/components/ui'

export default function GamePage() {
  const { id } = useParams()
  const { t } = useLang()
  const [game, setGame] = useState(undefined)
  useEffect(() => { getGame(id).then((g) => { setGame(g); if (g) remember(g) }) }, [id])

  if (game === undefined) return <p className="text-white/50" role="status">{t('loading')}</p>
  if (game === null) return <p>{t('notFound')} <Link href="/" className="text-accent underline">{t('back')}</Link></p>

  const total = game.votes ? game.votes[0] + game.votes[1] : 0
  const card = 'rounded-lg border border-white/[0.08] bg-surface p-5'
  const hi = 'rounded-lg border border-accent/40 bg-accent/[0.06] p-5'
  return (
    <article>
      <Link href="/" className="mb-6 inline-flex items-center gap-1 text-sm text-white/60 hover:text-white"><ArrowLeft size={16} aria-hidden />{t('back')}</Link>
      {game.estimated && <p className="mb-4 rounded-lg border border-white/[0.08] bg-surface p-3 text-sm text-white/60">{t('estimate')}</p>}
      <div className="grid gap-4 md:grid-cols-[1fr_320px]">
        <header className={`${card} flex flex-col gap-4 sm:flex-row`}>
          <Cover game={game} className="aspect-[460/215] w-full rounded-md sm:w-64" />
          <div>
            <h1 className="text-2xl font-semibold">{game.name}</h1>
            <p className="mt-1 text-white/60">{t('by')} {game.dev}</p>
            <p className="text-sm text-white/50">{t('released')} {game.date}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <SteamButton href={game.steamUrl} label={t('steam')} />
              <CopyLink />
              <WatchButton game={game} />
              <Link href={`/compare?a=${game.id}`} className="inline-flex items-center gap-2 rounded-md border border-white/[0.12] px-3 py-2 text-sm hover:border-accent hover:text-accent"><Scale size={16} aria-hidden />{t('compare')}</Link>
            </div>
          </div>
        </header>
        <section className={hi} aria-label={t('score')}><SlopMeter game={game} /></section>

        <section className={card} aria-labelledby="bd">
          <h2 id="bd" className="mb-4 flex items-center gap-2 font-semibold"><BarChart3 size={18} aria-hidden className="text-accent" />{t('breakdown')}</h2>
          <div className="space-y-4">
            <Bar label={t('art')} value={game.art} /><Bar label={t('text')} value={game.text} /><Bar label={t('flip')} value={game.flip} />
          </div>
        </section>

        <section className={card} aria-labelledby="ev">
          <h2 id="ev" className="mb-4 flex items-center gap-2 font-semibold"><FileSearch size={18} aria-hidden className="text-accent" />{t('evidence')}</h2>
          <ul className="space-y-3 text-sm">
            {game.flags.map((f) => (
              <li key={f} className="flex gap-2">
                {f === 'none' || f === 'preAi' ? <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-white/50" aria-hidden /> : <AlertTriangle size={16} className="mt-0.5 shrink-0 text-accent" aria-hidden />}
                <span>{t(`f_${f}`)}</span>
              </li>
            ))}
          </ul>
        </section>

        {game.sources?.length > 0 && (
          <section className={`${card} md:col-span-2`} aria-labelledby="src">
            <h2 id="src" className="mb-4 flex items-center gap-2 font-semibold"><Newspaper size={18} aria-hidden className="text-accent" />{t('sources')}</h2>
            <ul className="space-y-2 text-sm">
              {game.sources.map((x) => (
                <li key={x.url}>
                  <a href={x.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-accent underline">
                    {x.kind === 'video' ? <PlayCircle size={16} aria-hidden /> : <Newspaper size={16} aria-hidden />}{x.label}<ExternalLink size={12} aria-hidden />
                  </a>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section className={`${card} md:col-span-2`} aria-labelledby="cm">
          <h2 id="cm" className="mb-4 flex items-center gap-2 font-semibold"><Users size={18} aria-hidden className="text-accent" />{t('community')}</h2>
          <CommunityAi id={game.id} />
          <MyVerdict id={game.id} />
          <ul className="mt-5 flex flex-wrap gap-2" aria-label={t('tags')}>
            {game.tags.map((tag) => (
              <li key={tag}><Link href={`/tag/${encodeURIComponent(tag)}`} className="flex items-center gap-1 rounded-md border border-accent/30 bg-accent/[0.06] px-2 py-0.5 text-sm text-accent transition-colors hover:bg-accent/15"><Tag size={12} aria-hidden />{tag}</Link></li>
            ))}
          </ul>
        </section>
      </div>
    </article>
  )
}
