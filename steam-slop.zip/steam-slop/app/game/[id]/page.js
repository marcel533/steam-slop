'use client'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { useEffect, useState } from 'react'
import { ArrowLeft, AlertTriangle, CheckCircle2, ExternalLink, Quote } from 'lucide-react'
import { useLang } from '@/lib/i18n'
import { getGame } from '@/lib/games'
import { Bar, Cover, SlopMeter } from '@/components/ui'

export default function GamePage() {
  const { id } = useParams()
  const { t } = useLang()
  const [game, setGame] = useState(undefined)
  useEffect(() => { getGame(id).then(setGame) }, [id])

  if (game === undefined) return null
  if (game === null) return <p>{t('notFound')} <Link href="/" className="text-accent underline">{t('back')}</Link></p>

  const total = game.votes ? game.votes[0] + game.votes[1] : 0
  const card = 'rounded-lg border border-white/[0.08] bg-surface p-5'
  return (
    <article>
      <Link href="/" className="mb-6 inline-flex items-center gap-1 text-sm text-white/60 hover:text-white"><ArrowLeft size={16} aria-hidden />{t('back')}</Link>
      {game.estimated && <p className="mb-4 rounded-lg border border-white/[0.08] bg-surface p-3 text-sm text-white/60">{t('estimate')}</p>}
      <div className="grid gap-4 md:grid-cols-[1fr_320px]">
        <header className={`${card} flex flex-col gap-4 sm:flex-row`}>
          <Cover game={game} className="aspect-[460/215] w-full rounded-md sm:w-64" />
          <div>
            <h1 className="text-2xl font-semibold">{game.name}</h1>
            <p className="mt-1 text-white/60">{t('by')} {game.dev}</p>
            <p className="text-sm text-white/50">{t('released')} {game.date}</p>
            <a href={game.steamUrl} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-1 text-sm text-accent underline">{t('steam')}<ExternalLink size={14} aria-hidden /></a>
          </div>
        </header>
        <section className={card} aria-label={t('score')}><SlopMeter game={game} /></section>

        <section className={card} aria-labelledby="bd">
          <h2 id="bd" className="mb-4 font-semibold">{t('breakdown')}</h2>
          <div className="space-y-4">
            <Bar label={t('art')} value={game.art} /><Bar label={t('text')} value={game.text} /><Bar label={t('flip')} value={game.flip} />
          </div>
        </section>

        <section className={card} aria-labelledby="ev">
          <h2 id="ev" className="mb-4 font-semibold">{t('evidence')}</h2>
          <ul className="space-y-3 text-sm">
            {game.flags.map((f) => (
              <li key={f} className="flex gap-2">
                {f === 'none' ? <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-white/50" aria-hidden /> : <AlertTriangle size={16} className="mt-0.5 shrink-0 text-accent" aria-hidden />}
                <span>{t(`f_${f}`)}</span>
              </li>
            ))}
          </ul>
        </section>

        <section className={`${card} md:col-span-2`} aria-labelledby="cm">
          <h2 id="cm" className="mb-4 font-semibold">{t('community')}</h2>
          {total > 0 ? (<>
            <p className="mb-2 text-sm text-white/60">{total} {t('votes')}: {game.votes[0]} {t('voteSlop')}, {game.votes[1]} {t('voteClean')}</p>
            <div className="mb-5 flex h-1.5 overflow-hidden rounded-md bg-white/10" aria-hidden><div className="bg-accent" style={{ width: `${(game.votes[0] / total) * 100}%` }} /></div>
            {game.quote && <blockquote className="flex gap-2 text-sm text-white/80"><Quote size={16} className="mt-0.5 shrink-0 text-white/40" aria-hidden />{game.quote}</blockquote>}
          </>) : <p className="text-sm text-white/50">{t('noCommunity')}</p>}
          <ul className="mt-5 flex flex-wrap gap-2" aria-label={t('tags')}>
            {game.tags.map((tag) => (
              <li key={tag}><Link href={`/tag/${encodeURIComponent(tag)}`} className="block rounded-md border border-white/[0.08] px-2 py-0.5 text-sm text-white/70 transition-colors hover:border-accent hover:text-accent">{tag}</Link></li>
            ))}
          </ul>
        </section>
      </div>
    </article>
  )
}
