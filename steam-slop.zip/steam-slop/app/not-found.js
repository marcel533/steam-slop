'use client'
import Link from 'next/link'
import { useLang } from '@/lib/i18n'
export default function NotFound() {
  const { t } = useLang()
  return <div className="py-16 text-center"><h1 className="text-3xl font-semibold">{t('notFoundTitle')}</h1><p className="mt-3"><Link href="/" className="text-accent underline">{t('back')}</Link></p></div>
}
