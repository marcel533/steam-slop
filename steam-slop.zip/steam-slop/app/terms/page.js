import { LegalPage } from '@/components/legal-page'
import { TERMS } from '@/lib/legal'
export const metadata = { title: 'Terms of Service | Steam Slop' }
export default function Page() { return <LegalPage doc={TERMS} /> }
