import './globals.css'
import { LangProvider } from '@/lib/i18n'
import { Header } from '@/components/ui'
import { Footer } from '@/components/footer'
import { AiNotice } from '@/components/ai-notice'

export const metadata = { title: 'Steam Slop', description: 'Check Steam games for AI-generated assets.' }

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-base font-sans antialiased">
        <LangProvider>
          <AiNotice />
          <Header />
          <main className="mx-auto max-w-5xl px-4 py-10">{children}</main>
          <Footer />
        </LangProvider>
      </body>
    </html>
  )
}
