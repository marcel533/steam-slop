import './globals.css'
import { LangProvider } from '@/lib/i18n'
import { Header } from '@/components/ui'
import { Footer } from '@/components/footer'
import { AiNotice } from '@/components/ai-notice'
import { SkipLink } from '@/components/skip'
import { EventsBanner } from '@/components/events-banner'

export const metadata = { metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'), title: 'Steam Slop', openGraph: { title: 'Steam Slop', images: ['/logo.png'] }, description: 'Check Steam games for AI-generated assets.' }

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* The app is already dark. Dark Reader rewrites SVG attributes before hydration (hydration-mismatch error).
            Must sit directly in <head>: metadata-API tags are streamed in after </head>, too late for the extension. */}
        <meta name="darkreader-lock" />
      </head>
      <body className="min-h-screen bg-base font-sans antialiased">
        <LangProvider>
          <SkipLink />
          <AiNotice />
          <Header />
          <EventsBanner />
          <main id="main" className="mx-auto max-w-5xl px-4 py-10">{children}</main>
          <Footer />
        </LangProvider>
      </body>
    </html>
  )
}
