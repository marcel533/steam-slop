'use client'
import { useLang } from '@/lib/i18n'
export default function Error({ reset }) {
  const { t } = useLang()
  return (
    <div className="py-16 text-center">
      <h1 className="text-3xl font-semibold">{t('errorTitle')}</h1>
      <button onClick={reset} className="mt-4 rounded-md border border-white/[0.12] px-4 py-2 text-sm hover:border-accent hover:text-accent">{t('retry')}</button>
    </div>
  )
}
