import { LegalPage } from '@/components/legal-page'
import { IMPRESSUM } from '@/lib/legal'
export const metadata = { title: 'Impressum | Steam Slop' }
export default function Page() { return <LegalPage doc={IMPRESSUM} contactFirst /> }
