'use client'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { useEffect, useState } from 'react'
import { ArrowLeft } from 'lucide-react'
import { useLang } from '@/lib/i18n'
import { Cover } from '@/components/ui'

export default function TagPage() {
  const raw = useParams().name
  let name = raw
  try { name = decodeURIComponent(raw) } catch {}
  const { t } = useLang()
  const [games, setGames] = useState(undefined)

  useEffect(() => {
    let live = true
    setGames(undefined)
    fetch(`/api/tag?name=${encodeURIComponent(name)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => live && setGames(d))
      .catch(() => live && setGames(null))
    return () => { live = false }
  }, [name])

  return (
    <section aria-labelledby="tag">
      <Link href="/" className="mb-6 inline-flex items-center gap-1 text-sm text-white/60 hover:text-white"><ArrowLeft size={16} aria-hidden />{t('back')}</Link>
      <h1 id="tag" className="text-3xl font-semibold tracking-tight">{t('tagTitle')}: {name}</h1>
      <p className="mb-6 mt-1 text-sm text-white/50">{t('tagNote')}</p>
      {games === undefined && <p className="text-white/50" role="status">{t('loading')}</p>}
      {games === null && <p className="text-white/70">{t('tagError')}</p>}
      {games && games.length === 0 && <p className="text-white/70">{t('tagEmpty')}</p>}
      {games && games.length > 0 && (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {games.map((g) => {
            const total = g.pos + g.neg
            return (
              <li key={g.id}>
                <Link href={`/game/${g.id}`} className="block overflow-hidden rounded-lg border border-white/[0.08] bg-surface transition-colors hover:border-white/25">
                  <Cover game={g} className="aspect-[460/215] w-full" />
                  <div className="space-y-1 p-3">
                    <h2 className="font-medium leading-snug">{g.name}</h2>
                    <p className="text-sm text-white/50">{g.dev}</p>
                    {total > 0 && <p className="text-sm tabular-nums text-white/70">{Math.round((g.pos / total) * 100)}% {t('positive')}</p>}
                  </div>
                </Link>
              </li>
            )
          })}
        </ul>
      )}
    </section>
  )
}
