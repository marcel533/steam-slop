'use client'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { useEffect, useState } from 'react'
import { ArrowLeft, Tag } from 'lucide-react'
import { useLang } from '@/lib/i18n'
import { getGame } from '@/lib/games'
import { Cover, ScoreBadge } from '@/components/ui'

export default function TagPage() {
  const raw = useParams().name
  let name = raw
  try { name = decodeURIComponent(raw) } catch {}
  const { t } = useLang()
  const [games, setGames] = useState(undefined)
  const [scores, setScores] = useState({})
  const [ranking, setRanking] = useState(false)

  useEffect(() => {
    let live = true
    setGames(undefined); setScores({})
    fetch(`/api/tag?name=${encodeURIComponent(name)}`).then((r) => (r.ok ? r.json() : null)).then((d) => live && setGames(d)).catch(() => live && setGames(null))
    return () => { live = false }
  }, [name])

  // Rank the first 12 games by slop estimate, 3 requests at a time.
  const rank = async () => {
    setRanking(true)
    const list = games.slice(0, 12)
    let i = 0
    const worker = async () => {
      while (i < list.length) {
        const g = list[i++]
        const r = await getGame(g.id)
        if (r) setScores((s) => ({ ...s, [g.id]: r }))
      }
    }
    await Promise.all([worker(), worker(), worker()])
    setRanking(false)
  }
  const ranked = Object.keys(scores).length > 0
  const shown = games && ranked ? [...games].sort((a, b) => (scores[b.id]?.score ?? -1) - (scores[a.id]?.score ?? -1)) : games

  return (
    <section aria-labelledby="tag">
      <Link href="/" className="mb-6 inline-flex items-center gap-1 text-sm text-white/60 hover:text-white"><ArrowLeft size={16} aria-hidden />{t('back')}</Link>
      <h1 id="tag" className="flex flex-wrap items-center gap-2 text-3xl font-semibold tracking-tight"><Tag size={28} aria-hidden className="text-accent" />{t('tagTitle')}: <span className="text-accent">{name}</span></h1>
      <p className="mb-4 mt-1 text-sm text-white/50">{t('tagNote')}</p>
      {games && games.length > 0 && (
        <button onClick={rank} disabled={ranking} className="mb-6 rounded-md border border-accent/40 bg-accent/[0.06] px-3 py-2 text-sm text-accent hover:bg-accent/15 disabled:opacity-60">{ranking ? t('ranking') : t('rankBtn')}</button>
      )}
      {games === undefined && <p className="text-white/50" role="status">{t('loading')}</p>}
      {games === null && <p className="text-white/70">{t('tagError')}</p>}
      {games && games.length === 0 && <p className="text-white/70">{t('tagEmpty')}</p>}
      {shown && shown.length > 0 && (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((g) => {
            const total = g.pos + g.neg
            return (
              <li key={g.id}>
                <Link href={`/game/${g.id}`} className="block overflow-hidden rounded-lg border border-white/[0.08] bg-surface transition-colors hover:border-white/25">
                  <Cover game={g} className="aspect-[460/215] w-full" />
                  <div className="space-y-1 p-3">
                    <h2 className="font-medium leading-snug">{g.name}</h2>
                    <p className="text-sm text-white/50">{g.dev}</p>
                    {total > 0 && <p className="text-sm tabular-nums text-accent">{Math.round((g.pos / total) * 100)}% {t('positive')}</p>}
                    {scores[g.id] && <div className="pt-1"><ScoreBadge game={scores[g.id]} /></div>}
                  </div>
                </Link>
              </li>
            )
          })}
        </ul>
      )}
    </section>
  )
}
