'use client'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { ArrowLeft, Heart } from 'lucide-react'
import { useLang } from '@/lib/i18n'
import { getGame } from '@/lib/games'
import { getWatch, toggleWatch } from '@/lib/recent'
import { Cover, ScoreBadge } from '@/components/ui'

export default function Watchlist() {
  const { t } = useLang()
  const [list, setList] = useState(null)
  const [scores, setScores] = useState({})
  useEffect(() => { setList(getWatch()) }, [])
  useEffect(() => { // scores load one by one in the background (first 20) to stay friendly to Steam
    if (!list) return
    let live = true
    ;(async () => {
      for (const g of list.slice(0, 20)) {
        const r = await getGame(g.id)
        if (!live) return
        if (r) setScores((s) => ({ ...s, [g.id]: r }))
      }
    })()
    return () => { live = false }
  }, [list])
  const remove = (g) => { toggleWatch(g); setList(getWatch()) }
  return (
    <section>
      <Link href="/" className="mb-6 inline-flex items-center gap-1 text-sm text-white/60 hover:text-white"><ArrowLeft size={16} aria-hidden />{t('back')}</Link>
      <h1 className="mb-1 flex items-center gap-2 text-3xl font-semibold tracking-tight"><Heart size={28} aria-hidden className="text-accent" />{t('watch')}</h1>
      <p className="mb-6 text-sm text-white/50">{t('localOnly')}</p>
      {list && list.length === 0 && <p className="text-white/70">{t('watchEmpty')}</p>}
      {list && list.length > 0 && (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((g) => (
            <li key={g.id} className="overflow-hidden rounded-lg border border-white/[0.08] bg-surface">
              <Link href={`/game/${g.id}`} className="block"><Cover game={g} className="aspect-[460/215] w-full" /></Link>
              <div className="space-y-2 p-3">
                <h2 className="font-medium leading-snug"><Link href={`/game/${g.id}`} className="hover:text-accent">{g.name}</Link></h2>
                {scores[g.id] && <ScoreBadge game={scores[g.id]} />}
                <div><button onClick={() => remove(g)} className="text-sm text-white/50 underline hover:text-white">{t('remove')}</button></div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}
