import { LegalPage } from '@/components/legal-page'
import { METHOD } from '@/lib/legal'
export const metadata = { title: 'How scores work | Steam Slop' }
export default function Page() { return <LegalPage doc={METHOD} /> }
