'use client'
import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { useLang } from '@/lib/i18n'
import { getTopSlop } from '@/lib/games'
import { GameCard, SearchBar } from '@/components/ui'

gsap.registerPlugin(useGSAP)

export default function Home() {
  const { t } = useLang()
  const [top, setTop] = useState([])
  const hero = useRef(null)
  useEffect(() => { getTopSlop(6).then(setTop) }, [])
  // One orchestrated moment: the hero lines settle in once on load.
  useGSAP(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    gsap.from('[data-line]', { y: 14, opacity: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out' })
  }, { scope: hero })

  return (
    <>
      <section ref={hero} className="py-12 text-center">
        <h1 data-line className="text-5xl font-semibold tracking-tight sm:text-6xl">Steam Slop</h1>
        <p data-line className="mx-auto mt-4 max-w-md text-lg text-white/60">{t('tagline')}</p>
        <div data-line className="mt-8"><SearchBar /></div>
      </section>
      <section aria-labelledby="top" className="mt-8">
        <h2 id="top" className="text-xl font-semibold">{t('top')}</h2>
        <p className="mb-4 text-sm text-white/50">{t('topSub')}</p>
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {top.map((g) => <li key={g.id}><GameCard game={g} /></li>)}
        </ul>
      </section>
    </>
  )
}
