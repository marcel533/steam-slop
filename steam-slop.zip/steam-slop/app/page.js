'use client'
import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { useLang } from '@/lib/i18n'
import Link from 'next/link'
import { getTopSlop } from '@/lib/games'
import { getRecent } from '@/lib/recent'
import { GameCard, SearchBar } from '@/components/ui'
import { SteamLogo } from '@/components/brand'

gsap.registerPlugin(useGSAP)

export default function Home() {
  const { t } = useLang()
  const [top, setTop] = useState([])
  const hero = useRef(null)
  const [filter, setFilter] = useState('all')
  const [recent, setRecent] = useState([])
  useEffect(() => { setRecent(getRecent()) }, [])
  useEffect(() => { getTopSlop(20).then(setTop) }, [])
  // One orchestrated moment: the hero lines settle in once on load.
  useGSAP(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    gsap.from('[data-line]', { y: 14, opacity: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out' })
  }, { scope: hero })

  return (
    <>
      <section ref={hero} className="py-12 text-center">
        <img data-line src="/logo.png" alt="" width={96} height={96} className="mx-auto mb-4 rounded-lg" />
        <h1 data-line className="text-5xl font-semibold tracking-tight sm:text-6xl">Steam <span className="text-accent">Slop</span></h1>
        <p data-line className="mx-auto mt-4 max-w-md text-lg text-white/60">{t('tagline')}</p>
        <div data-line className="mt-8"><SearchBar /></div>
        <p data-line className="mt-4 flex items-center justify-center gap-2 text-sm text-white/40"><SteamLogo size={16} />{t('steamData')}</p>
      </section>
      {recent.length > 0 && (
        <section aria-labelledby="rc" className="mt-4">
          <h2 id="rc" className="mb-2 text-sm text-white/50">{t('recent')}</h2>
          <ul className="flex flex-wrap gap-2">{recent.map((g) => <li key={g.id}><Link href={`/game/${g.id}`} className="block rounded-md border border-white/[0.08] bg-surface px-3 py-1 text-sm hover:border-accent">{g.name}</Link></li>)}</ul>
        </section>
      )}
      <section aria-labelledby="top" className="mt-8">
        <h2 id="top" className="border-l-2 border-accent pl-3 text-xl font-semibold">{t('top')}</h2>
        <p className="mb-3 text-sm text-white/50">{t('topSub')}</p>
        <div role="group" aria-label={t('filter')} className="mb-4 flex flex-wrap gap-2">
          {['all', 'slop', 'mixed', 'clean'].map((f) => (
            <button key={f} onClick={() => setFilter(f)} aria-pressed={filter === f}
              className={`rounded-md border px-3 py-1.5 text-sm transition-colors ${filter === f ? 'border-accent bg-accent text-black' : 'border-white/[0.12] text-white/70 hover:border-accent'}`}>{f === 'all' ? t('filterAll') : t(f)}</button>
          ))}
        </div>
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {top.filter((g) => filter === 'all' || g.verdict === filter).map((g) => <li key={g.id}><GameCard game={g} /></li>)}
        </ul>
      </section>
    </>
  )
}
