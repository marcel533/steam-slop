import { reviewAiStats } from '@/lib/reviews'
import { limited, tooMany } from '@/lib/ratelimit'

export async function GET(req, { params }) {
  if (limited(req)) return tooMany()
  const { id } = await params
  if (!/^\d{1,10}$/.test(id)) return Response.json({ error: 'bad id' }, { status: 400 })
  return Response.json(await reviewAiStats(id), { headers: { 'Cache-Control': 'public, s-maxage=3600' } })
}
