import { analyze } from '@/lib/analyze'

export async function GET(_req, { params }) {
  const { id } = await params
  if (!/^\d{1,10}$/.test(id)) return Response.json({ error: 'bad id' }, { status: 400 })
  try {
    const g = await analyze(id)
    return g ? Response.json(g) : Response.json({ error: 'not found' }, { status: 404 })
  } catch { return Response.json({ error: 'upstream' }, { status: 502 }) }
}
