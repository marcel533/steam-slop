import { UA } from '@/lib/analyze'
import { limited, tooMany } from '@/lib/ratelimit'

export async function GET(req) {
  if (limited(req)) return tooMany()
  const sp = new URL(req.url).searchParams
  const q = (sp.get('q') ?? '').trim().slice(0, 64)
  const limit = Math.min(12, Math.max(1, Number(sp.get('limit')) || 6))
  if (!q) return Response.json([])
  try {
    const r = await fetch(`https://store.steampowered.com/api/storesearch/?term=${encodeURIComponent(q)}&cc=us&l=en`,
      { headers: UA, signal: AbortSignal.timeout(8000), next: { revalidate: 300 } })
    if (!r.ok) return Response.json([], { status: 502 })
    const seen = new Set() // Steam can list editions or bundles under the same name
    const items = ((await r.json()).items ?? []).filter((i) => { const k = (i.name || '').toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true }).slice(0, limit)
    const out = await Promise.all(items.map(async (i) => {
      const base = { id: String(i.id), name: i.name, dev: '', date: '', tiny: i.tiny_image ?? '' }
      try {
        const d = (await (await fetch(`https://store.steampowered.com/api/appdetails?appids=${i.id}&filters=basic&l=english`,
          { headers: UA, signal: AbortSignal.timeout(8000), next: { revalidate: 3600 } })).json())?.[i.id]?.data
        return { ...base, dev: d?.developers?.[0] ?? '', date: d?.release_date?.date ?? '', img: d?.header_image ?? '' }
      } catch { return base }
    }))
    return Response.json(out)
  } catch { return Response.json([], { status: 502 }) }
}
