import { UA } from '@/lib/analyze'

export async function GET(req) {
  const q = (new URL(req.url).searchParams.get('q') ?? '').trim().slice(0, 64)
  if (!q) return Response.json([])
  try {
    const r = await fetch(`https://store.steampowered.com/api/storesearch/?term=${encodeURIComponent(q)}&cc=us&l=en`,
      { headers: UA, signal: AbortSignal.timeout(8000), next: { revalidate: 300 } })
    if (!r.ok) return Response.json([], { status: 502 })
    const items = ((await r.json()).items ?? []).slice(0, 6)
    const out = await Promise.all(items.map(async (i) => {
      const base = { id: String(i.id), name: i.name, dev: '', date: '' }
      try {
        const d = (await (await fetch(`https://store.steampowered.com/api/appdetails?appids=${i.id}&filters=basic&l=english`,
          { headers: UA, signal: AbortSignal.timeout(8000), next: { revalidate: 3600 } })).json())?.[i.id]?.data
        return { ...base, dev: d?.developers?.[0] ?? '', date: d?.release_date?.date ?? '' }
      } catch { return base }
    }))
    return Response.json(out)
  } catch { return Response.json([], { status: 502 }) }
}
