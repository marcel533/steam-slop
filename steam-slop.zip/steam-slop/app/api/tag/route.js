import { UA } from '@/lib/analyze'
import { limited, tooMany } from '@/lib/ratelimit'

// Tag overview via SteamSpy (public Steam user tags). Validate input, return the top 48 by positive reviews.
export async function GET(req) {
  if (limited(req)) return tooMany()
  const name = (new URL(req.url).searchParams.get('name') ?? '').trim()
  if (!/^[\p{L}\p{N} '\-&.+!:]{1,40}$/u.test(name)) return Response.json({ error: 'bad tag' }, { status: 400 })
  try {
    const r = await fetch(`https://steamspy.com/api.php?request=tag&tag=${encodeURIComponent(name)}`,
      { headers: UA, cache: 'no-store', signal: AbortSignal.timeout(15000) })
    if (!r.ok) return Response.json({ error: 'upstream' }, { status: 502 })
    const games = Object.values((await r.json()) ?? {})
      .filter((g) => g && g.appid && g.name)
      .sort((a, b) => (b.positive ?? 0) - (a.positive ?? 0))
      .filter((g, i, a) => a.findIndex((x) => x.name.toLowerCase() === g.name.toLowerCase()) === i)
      .slice(0, 48)
      .map((g) => ({ id: String(g.appid), name: g.name, dev: g.developer ?? '', pos: g.positive ?? 0, neg: g.negative ?? 0 }))
    return Response.json(games, { headers: { 'Cache-Control': 'public, s-maxage=3600' } })
  } catch { return Response.json({ error: 'upstream' }, { status: 502 }) }
}
