'use client'
import Link from 'next/link'
import { Suspense, useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { ArrowLeft } from 'lucide-react'
import { useLang } from '@/lib/i18n'
import { getGame } from '@/lib/games'
import { Bar, Cover, ScoreBadge, SearchBar } from '@/components/ui'

const ok = (x) => /^\d{1,10}$/.test(x)

function Col({ game }) {
  const { t } = useLang()
  return (
    <div className="overflow-hidden rounded-lg border border-white/[0.08] bg-surface">
      <Cover game={game} className="aspect-[460/215] w-full" />
      <div className="space-y-4 p-4">
        <div>
          <h2 className="font-semibold"><Link href={`/game/${game.id}`} className="hover:text-accent">{game.name}</Link></h2>
          <p className="text-sm text-white/50">{game.dev}</p>
          <div className="mt-2"><ScoreBadge game={game} /></div>
        </div>
        <Bar label={t('art')} value={game.art} /><Bar label={t('text')} value={game.text} /><Bar label={t('flip')} value={game.flip} />
        <ul className="space-y-1 text-sm text-white/70">{game.flags.map((f) => <li key={f}>{t(`f_${f}`)}</li>)}</ul>
      </div>
    </div>
  )
}

function Compare() {
  const sp = useSearchParams()
  const router = useRouter()
  const { t } = useLang()
  const a = sp.get('a') ?? '', b = sp.get('b') ?? ''
  const [ga, setA] = useState(null), [gb, setB] = useState(null)
  useEffect(() => { ok(a) ? getGame(a).then(setA) : setA(null) }, [a])
  useEffect(() => { ok(b) ? getGame(b).then(setB) : setB(null) }, [b])
  const pick = (g) => router.replace(ok(a) ? `/compare?a=${a}&b=${g.id}` : `/compare?a=${g.id}`)
  return (
    <section>
      <Link href="/" className="mb-6 inline-flex items-center gap-1 text-sm text-white/60 hover:text-white"><ArrowLeft size={16} aria-hidden />{t('back')}</Link>
      <h1 className="mb-4 text-3xl font-semibold tracking-tight">{t('compareTitle')}</h1>
      {(!ga || !gb) && <div className="mb-6"><p className="mb-2 text-sm text-white/60">{t('comparePick')}</p><SearchBar onPick={pick} /></div>}
      <div className="grid gap-4 sm:grid-cols-2">{ga && <Col game={ga} />}{gb && <Col game={gb} />}</div>
    </section>
  )
}
export default function Page() { return <Suspense fallback={null}><Compare /></Suspense> }
