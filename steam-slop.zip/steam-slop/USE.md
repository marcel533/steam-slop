# Steam Slop: How to run it / So startest du es

[English](#english) | [Deutsch](#deutsch)

---

<a id="english"></a>

# English

Next.js app (App Router) with Tailwind, Lucide and GSAP. Search and analysis use Steam store data.

## Requirements

- Node.js 18.18 or newer (20 LTS recommended)
- npm (comes with Node)
- Internet connection (Steam requests and cover images)

Check:

```bash
node -v
npm -v
```

### Install Node (Linux, e.g. Bazzite)

Bazzite is an immutable system, so install Node in your home directory:

```bash
curl -fsSL -o /tmp/nvm-install.sh https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh
bash /tmp/nvm-install.sh
source ~/.bashrc
nvm install 20
nvm use 20
```

Alternative with Homebrew:

```bash
ujust install-brew
brew install node@20
```

## Start (development)

```bash
cd steam-slop
npm install
npm run dev
```

Then open http://localhost:3000

Different port:

```bash
npm run dev -- -p 4000
```

Local only (no access from your network):

```bash
npm run dev -- -H 127.0.0.1
```

## Stop

Press `Ctrl+C` in the terminal. If the server still runs in the background:

```bash
fuser -k 3000/tcp
```

## Production mode

```bash
npm run build
npm run start
```

## Usage

1. Type a game or developer name in the search bar. Results come live from Steam.
2. Pick a game with the arrow keys and Enter, or click it.
3. The game page shows the slop score, breakdown, evidence and a link to its Steam page.
4. Switch between EN and DE at the top right.

Note: for arbitrary games the score is an automatic estimate from public store data. Images are not analyzed. Curated entries on the home page are based on publicly known statements.

## Project structure

```
app/                    pages and API routes
  api/search/           Steam search (server side)
  api/game/[id]/        game analysis (server side)
  game/[id]/            game page
components/             UI parts
lib/games.js            curated entries, score calculation, client data access
lib/analyze.js          estimate from Steam store data (server only)
lib/i18n.js             EN/DE texts
```

## Troubleshooting

Port in use:

```bash
ss -ltnp | grep 3000
kill <PID>
```

Broken styles or build:

```bash
rm -rf .next
npm run dev
```

Broken install:

```bash
rm -rf node_modules package-lock.json
npm install
```

Search returns nothing: test the API directly.

```bash
curl -s "http://localhost:3000/api/search?q=hades" | head -c 400
curl -s "http://localhost:3000/api/game/1145360"
```

## Publishing

GitHub Pages cannot run server routes. Put the code on GitHub and deploy from there to Vercel (no API key needed).

## AI disclosure

This project is fully generated with AI, because it is so difficult to build this by hand. The app shows this notice at the top of every page (dismissible) and in the footer. Text: `ai` in `lib/i18n.js`.

---

<a id="deutsch"></a>

# Deutsch

Next.js-App (App Router) mit Tailwind, Lucide und GSAP. Suche und Analyse nutzen Steam-Store-Daten.

## Voraussetzungen

- Node.js 18.18 oder neuer (20 LTS empfohlen)
- npm (ist bei Node dabei)
- Internetverbindung (Steam-Abfragen und Cover-Bilder)

Prüfen:

```bash
node -v
npm -v
```

### Node installieren (Linux, z. B. Bazzite)

Bazzite ist ein unveränderliches System, daher Node im Home-Verzeichnis installieren:

```bash
curl -fsSL -o /tmp/nvm-install.sh https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh
bash /tmp/nvm-install.sh
source ~/.bashrc
nvm install 20
nvm use 20
```

Alternative mit Homebrew:

```bash
ujust install-brew
brew install node@20
```

## Starten (Entwicklung)

```bash
cd steam-slop
npm install
npm run dev
```

Dann im Browser öffnen: http://localhost:3000

Anderer Port:

```bash
npm run dev -- -p 4000
```

Nur lokal erreichbar (kein Zugriff aus dem LAN):

```bash
npm run dev -- -H 127.0.0.1
```

## Stoppen

`Ctrl+C` im Terminal. Läuft der Server noch im Hintergrund:

```bash
fuser -k 3000/tcp
```

## Produktionsmodus

```bash
npm run build
npm run start
```

## Benutzung

1. Spielnamen oder Entwickler in die Suche eingeben. Treffer kommen live von Steam.
2. Mit Pfeiltasten und Enter oder per Klick ein Spiel öffnen.
3. Die Spielseite zeigt Slop-Wert, Aufschlüsselung, Belege und einen Link zur Steam-Seite.
4. Oben rechts zwischen EN und DE wechseln.

Hinweis: Für beliebige Spiele ist der Wert eine automatische Schätzung aus öffentlichen Store-Daten. Bilder werden nicht analysiert. Kuratierte Einträge (Startseite) basieren auf öffentlich bekannten Angaben.

## Projektstruktur

```
app/                    Seiten und API-Routen
  api/search/           Steam-Suche (serverseitig)
  api/game/[id]/        Spielanalyse (serverseitig)
  game/[id]/            Spielseite
components/             UI-Bausteine
lib/games.js            kuratierte Einträge, Score-Berechnung, Client-Datenzugriff
lib/analyze.js          Schätzung aus Steam-Store-Daten (nur Server)
lib/i18n.js             Texte EN/DE
```

## Fehlerbehebung

Port belegt:

```bash
ss -ltnp | grep 3000
kill <PID>
```

Styles oder Build kaputt:

```bash
rm -rf .next
npm run dev
```

Installation kaputt:

```bash
rm -rf node_modules package-lock.json
npm install
```

Suche liefert nichts: API direkt testen.

```bash
curl -s "http://localhost:3000/api/search?q=hades" | head -c 400
curl -s "http://localhost:3000/api/game/1145360"
```

## Veröffentlichen

GitHub Pages kann keine Server-Routen ausführen. Code auf GitHub ablegen und von dort auf Vercel deployen (kein API-Key nötig).

## KI-Hinweis

Dieses Projekt ist vollständig mit KI generiert, weil es so schwierig ist, so etwas von Hand zu bauen. Die App zeigt diesen Hinweis oben auf jeder Seite (schließbar) und im Footer. Text: `ai` in `lib/i18n.js`.

---

Created by / Erstellt von marcel533
