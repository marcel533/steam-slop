'use client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect, useId, useRef, useState } from 'react'
import { Bot, Gamepad2, Heart, Scale, Search, ShieldCheck } from 'lucide-react'
import { getWatch } from '@/lib/recent'
import gsap from 'gsap'
import { useGSAP } from '@gsap/react'
import { useLang } from '@/lib/i18n'
import { coverSources, searchGames } from '@/lib/games'

gsap.registerPlugin(useGSAP)
const reduced = () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

export function Header() {
  const { lang, setLang, t } = useLang()
  const [n, setN] = useState(0)
  useEffect(() => {
    const sync = () => setN(getWatch().length)
    sync()
    window.addEventListener('ss-watch', sync)
    window.addEventListener('storage', sync)
    return () => { window.removeEventListener('ss-watch', sync); window.removeEventListener('storage', sync) }
  }, [])
  const btn = (l) => `px-2 py-1 rounded-md text-sm ${lang === l ? 'bg-white/10 text-white' : 'text-white/50 hover:text-white'}`
  return (
    <header className="border-b border-white/[0.08]">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight"><img src="/logo.png" alt="" width={28} height={28} className="rounded-md" />Steam<span className="text-accent">Slop</span></Link>
        <div className="flex items-center gap-3">
        <Link href="/watchlist" aria-label={t('watch')} className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-sm text-white/60 hover:text-white"><Heart size={16} aria-hidden className="text-accent" /><span className="tabular-nums">{n}</span></Link>
        <div role="group" aria-label={t('language')} className="flex items-center gap-1 text-white/30">
          <button className={btn('en')} aria-pressed={lang === 'en'} onClick={() => setLang('en')}>EN</button>
          |
          <button className={btn('de')} aria-pressed={lang === 'de'} onClick={() => setLang('de')}>DE</button>
        </div>
        </div>
      </div>
    </header>
  )
}

export function Cover({ game, className = '' }) {
  const [i, setI] = useState(0)
  useEffect(() => setI(0), [game.id])
  const src = coverSources(game)[i]
  return src ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img key={src} src={src} alt="" loading="lazy" referrerPolicy="no-referrer" onError={() => setI((n) => n + 1)} className={`object-cover ${className}`} />
  ) : (
    <div aria-hidden className={`grid place-items-center bg-white/[0.04] text-white/30 ${className}`}><Gamepad2 size={24} /></div>
  )
}

export function ScoreBadge({ game }) {
  const { t } = useLang()
  const tone = game.verdict === 'slop' ? 'bg-accent text-black' : game.verdict === 'mixed' ? 'border border-accent text-accent' : 'border border-white/20 text-white/60'
  const Icon = game.verdict === 'slop' ? Bot : game.verdict === 'mixed' ? Scale : ShieldCheck
  return <span className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-sm font-medium tabular-nums ${tone}`}><Icon size={14} aria-hidden />{game.score}% {t(game.verdict)}</span>
}

export function GameCard({ game }) {
  const { t } = useLang()
  return (
    <Link href={`/game/${game.id}`} className={`block overflow-hidden rounded-lg border border-t-2 border-white/[0.08] bg-surface transition-colors hover:border-white/25 ${game.verdict === 'slop' ? 'border-t-accent' : game.verdict === 'mixed' ? 'border-t-accent/50' : 'border-t-white/10'}`}>
      <Cover game={game} className="aspect-[460/215] w-full" />
      <div className="space-y-2 p-3">
        <h3 className="font-medium leading-snug">{game.name}</h3>
        <p className="text-sm text-white/50">{t('by')} {game.dev}</p>
        <ScoreBadge game={game} />
      </div>
    </Link>
  )
}

export function SearchBar({ onPick }) {
  const { t } = useLang()
  const router = useRouter()
  const listId = useId()
  const [q, setQ] = useState('')
  const [results, setResults] = useState([])
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState(-1)
  const box = useRef(null)

  useEffect(() => {
    let live = true
    const h = setTimeout(async () => {
      const r = await searchGames(q)
      if (live) { setResults(r); setActive(-1) }
    }, 120)
    return () => { live = false; clearTimeout(h) }
  }, [q])
  useEffect(() => {
    const off = (e) => { if (!box.current?.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', off)
    return () => document.removeEventListener('mousedown', off)
  }, [])

  useEffect(() => { // press / to jump to the search field
    const k = (e) => { if (e.key === '/' && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName)) { e.preventDefault(); document.getElementById('q')?.focus() } }
    document.addEventListener('keydown', k)
    return () => document.removeEventListener('keydown', k)
  }, [])

  const go = (g) => (onPick ? onPick(g) : router.push(`/game/${g.id}`))
  const onKey = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setActive((a) => Math.min(a + 1, results.length - 1)) }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)) }
    else if (e.key === 'Enter') {
      if (active >= 0 && results[active]) go(results[active])
      else if (onPick && results[0]) go(results[0])
      else if (q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`)
    }
    else if (e.key === 'Escape') setOpen(false)
  }

  return (
    <div ref={box} className="relative mx-auto w-full max-w-xl text-left">
      <label htmlFor="q" className="sr-only">{t('searchLabel')}</label>
      <Search size={18} aria-hidden className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-accent" />
      <input id="q" type="search" autoComplete="off" value={q} placeholder={t('searchPh')}
        role="combobox" aria-expanded={open && q.trim() !== ''} aria-controls={listId} aria-autocomplete="list"
        aria-activedescendant={active >= 0 ? `${listId}-${active}` : undefined}
        onChange={(e) => { setQ(e.target.value); setOpen(true) }} onFocus={() => setOpen(true)} onKeyDown={onKey}
        className="w-full rounded-lg border border-white/[0.08] bg-surface py-3 pl-10 pr-3 placeholder:text-white/40 focus:border-accent" />
      {open && q.trim() !== '' && (
        <ul id={listId} role="listbox" className="absolute z-10 mt-2 max-h-96 w-full overflow-auto rounded-lg border border-white/[0.08] bg-surface">
          {results.length === 0 && <li className="px-3 py-3 text-sm text-white/50">{t('noResults')}</li>}
          {results.map((g, i) => (
            <li key={g.id} id={`${listId}-${i}`} role="option" aria-selected={i === active}
              onMouseDown={() => go(g)} onMouseEnter={() => setActive(i)}
              className={`flex cursor-pointer items-center gap-3 p-2 ${i === active ? 'bg-accent/10' : ''}`}>
              <Cover game={g} className="h-12 w-24 shrink-0 rounded-md" />
              <span className="min-w-0 flex-1">
                <span className="block truncate font-medium">{g.name}</span>
                <span className="block truncate text-sm text-white/50">{g.dev}, {g.date}</span>
              </span>
              {g.score != null && <ScoreBadge game={g} />}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

// Animated score: counts up once on mount; static for reduced motion.
export function SlopMeter({ game }) {
  const { t } = useLang()
  const root = useRef(null)
  useGSAP(() => {
    const num = root.current.querySelector('[data-num]')
    const fill = root.current.querySelector('[data-fill]')
    if (reduced()) { num.textContent = game.score; return }
    const o = { v: 0 }
    gsap.fromTo(fill, { scaleX: 0 }, { scaleX: game.score / 100, duration: 1.1, ease: 'power3.out' })
    gsap.to(o, { v: game.score, duration: 1.1, ease: 'power3.out', onUpdate: () => (num.textContent = Math.round(o.v)) })
  }, { scope: root, dependencies: [game.score] })
  return (
    <div ref={root}>
      <p className="text-sm text-white/50">{t('score')}</p>
      <p className="mt-1 flex items-baseline gap-2">
        <span className="text-6xl font-semibold tabular-nums"><span data-num>0</span>%</span>
        <span className="text-xl text-accent">{t(game.verdict)}</span>
      </p>
      <div role="meter" aria-valuenow={game.score} aria-valuemin={0} aria-valuemax={100} aria-label={t('score')} className="mt-3 h-2 overflow-hidden rounded-md bg-white/10">
        <div data-fill style={{ transform: `scaleX(${game.score / 100})` }} className="h-full origin-left bg-accent" />
      </div>
    </div>
  )
}

export function Bar({ label, value }) {
  if (value == null) return <div className="flex justify-between text-sm text-white/40"><span>{label}</span><span>n/a</span></div>
  return (
    <div>
      <div className="mb-1 flex justify-between text-sm"><span>{label}</span><span className="tabular-nums text-white/60">{value}%</span></div>
      <div role="meter" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100} aria-label={label} className="h-1.5 overflow-hidden rounded-md bg-white/10">
        <div style={{ width: `${value}%` }} className="h-full bg-accent" />
      </div>
    </div>
  )
}
