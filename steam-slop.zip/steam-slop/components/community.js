'use client'
import { useEffect, useState } from 'react'
import { Check, Heart, Link2, Quote } from 'lucide-react'
import { useLang } from '@/lib/i18n'
import { LEGAL } from '@/lib/legal'
import { getVerdict, getWatch, setVerdict, toggleWatch } from '@/lib/recent'
import { DiscordButton } from '@/components/brand'

// Live from Steam: share of the latest reviews (up to 300) that mention AI-generated content.
export function CommunityAi({ id }) {
  const { t } = useLang()
  const [s, setS] = useState(undefined)
  useEffect(() => {
    let live = true
    setS(undefined)
    fetch(`/api/reviews/${id}`).then((r) => (r.ok ? r.json() : null)).then((d) => live && setS(d)).catch(() => live && setS(null))
    return () => { live = false }
  }, [id])

  if (s === undefined) return <p className="text-sm text-white/50" role="status">{t('loading')}</p>
  if (!s || !s.sample) return <p className="text-sm text-white/50">{t('noCommunity')}</p>
  const pct = Math.round((s.mentions / s.sample) * 100)
  const cats = Object.entries(s.cats || {}).sort((a, b) => b[1] - a[1])
  return (
    <div>
      <p className="mb-2 text-sm text-white/60"><span className="tabular-nums text-white">{s.mentions} / {s.sample}</span> {t('reviewsMention')} ({pct}%)</p>
      <div className="mb-3 h-1.5 overflow-hidden rounded-md bg-white/10" aria-hidden><div className="h-full bg-accent" style={{ width: `${pct}%` }} /></div>
      {s.mentions > 0 && <p className="mb-3 text-sm text-white/60">{s.up} {t('recommendAnyway')}, {s.down} {t('notRecommend')}</p>}
      {cats.length > 0 && (
        <ul className="mb-5 flex flex-wrap gap-2" aria-label={t('aboutWhat')}>
          {cats.map(([k, n]) => <li key={k} className="rounded-md border border-accent/30 bg-accent/[0.06] px-2 py-0.5 text-sm text-accent">{t(`cat_${k}`)} <span className="tabular-nums">{n}</span></li>)}
        </ul>
      )}
      <ul className="space-y-3">
        {s.snippets.map((x, i) => (
          <li key={i} className="flex gap-2 text-sm text-white/80">
            <Quote size={16} className="mt-0.5 shrink-0 text-accent" aria-hidden />
            <div><p>{x.text}</p><p className="mt-1 text-xs text-white/40">{t('steamReview')}, {x.up ? t('recommended') : t('notRecommended')}</p></div>
          </li>
        ))}
      </ul>
    </div>
  )
}

// Own verdict, stored only in this browser. Shared votes would need a database.
export function MyVerdict({ id }) {
  const { t } = useLang()
  const [v, setV] = useState(null)
  useEffect(() => { setV(getVerdict(id)) }, [id])
  const pick = (x) => { const n = v === x ? null : x; setV(n); setVerdict(id, n) }
  return (
    <div className="mt-6 border-t border-white/[0.08] pt-5">
      <p className="mb-2 text-sm font-medium">{t('yourVerdict')}</p>
      <div role="group" aria-label={t('yourVerdict')} className="flex flex-wrap gap-2">
        {['slop', 'mixed', 'clean'].map((x) => (
          <button key={x} onClick={() => pick(x)} aria-pressed={v === x}
            className={`rounded-md border px-3 py-1.5 text-sm transition-colors ${v === x ? 'border-accent bg-accent text-black' : 'border-white/[0.12] text-white/70 hover:border-accent'}`}>{t(x)}</button>
        ))}
      </div>
      <p className="mt-2 text-xs text-white/40">{t('localOnly')}</p>
      <DiscordButton href={LEGAL.discord} label={t('report')} className="mt-4" />
    </div>
  )
}

export function CopyLink() {
  const { t } = useLang()
  const [ok, setOk] = useState(false)
  const copy = async () => { try { await navigator.clipboard.writeText(window.location.href); setOk(true); setTimeout(() => setOk(false), 1500) } catch {} }
  return (
    <button onClick={copy} className="inline-flex items-center gap-2 rounded-md border border-white/[0.12] px-3 py-2 text-sm hover:border-accent hover:text-accent">
      {ok ? <Check size={16} aria-hidden /> : <Link2 size={16} aria-hidden />}{ok ? t('copied') : t('copyLink')}
    </button>
  )
}

export function WatchButton({ game }) {
  const { t } = useLang()
  const [on, setOn] = useState(false)
  useEffect(() => { setOn(getWatch().some((x) => x.id === game.id)) }, [game.id])
  return (
    <button onClick={() => setOn(toggleWatch(game))} aria-pressed={on}
      className={`inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm transition-colors ${on ? 'border-accent bg-accent/10 text-accent' : 'border-white/[0.12] hover:border-accent hover:text-accent'}`}>
      <Heart size={16} aria-hidden fill={on ? 'currentColor' : 'none'} />{on ? t('watchRemove') : t('watchAdd')}
    </button>
  )
}
