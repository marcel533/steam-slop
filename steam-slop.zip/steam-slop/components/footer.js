'use client'
import { useLang } from '@/lib/i18n'
export function Footer() {
  const { t } = useLang()
  return (
    <footer className="mx-auto max-w-5xl border-t border-white/[0.08] px-4 py-6 text-sm text-white/50">
      <p>{t('ai')}</p>
      <p className="mt-1">{t('sample')}</p>
      <p className="mt-1">{t('footer')}</p>
    </footer>
  )
}
