'use client'
import Link from 'next/link'
import { useLang } from '@/lib/i18n'
import { LEGAL } from '@/lib/legal'
import { DiscordButton } from '@/components/brand'

export function Footer() {
  const { t } = useLang()
  return (
    <footer className="mx-auto max-w-5xl border-t border-white/[0.08] px-4 py-6 text-sm text-white/50">
      <p>{t('ai')}</p>
      <p className="mt-1">{t('sample')}</p>
      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-3">
        <DiscordButton href={LEGAL.discord} label={t('discordJoin')} />
        <nav aria-label={t('legalNav')} className="flex flex-wrap gap-x-4 gap-y-1">
          <Link href="/impressum" className="underline hover:text-white">{t('impressum')}</Link>
          <Link href="/method" className="underline hover:text-white">{t('method')}</Link>
          <Link href="/terms" className="underline hover:text-white">{t('terms')}</Link>
        </nav>
      </div>
      <p className="mt-4">{t('footer')}</p>
    </footer>
  )
}
