'use client'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { DiscordButton } from '@/components/brand'
import { useLang } from '@/lib/i18n'
import { LEGAL } from '@/lib/legal'

function Contact() {
  const { t } = useLang()
  return (
    <section aria-labelledby="contact" className="rounded-lg border border-white/[0.08] bg-surface p-5">
      <h2 id="contact" className="mb-3 font-semibold">{t('contactTitle')}</h2>
      <dl className="space-y-1 text-sm">
        <div className="flex gap-2"><dt className="text-white/50">{t('legalName')}:</dt><dd>{LEGAL.name}</dd></div>
        {LEGAL.address && <div className="flex gap-2"><dt className="text-white/50">{t('legalAddress')}:</dt><dd className="whitespace-pre-line">{LEGAL.address}</dd></div>}
        {LEGAL.email && <div className="flex gap-2"><dt className="text-white/50">E-Mail:</dt><dd><a className="text-accent underline" href={`mailto:${LEGAL.email}`}>{LEGAL.email}</a></dd></div>}
        </dl>
      <DiscordButton href={LEGAL.discord} label={t('discordJoin')} className="mt-4" />
    </section>
  )
}

export function LegalPage({ doc, contactFirst = false }) {
  const { lang, t } = useLang()
  const d = doc[lang]
  return (
    <article className="max-w-3xl space-y-6">
      <Link href="/" className="inline-flex items-center gap-1 text-sm text-white/60 hover:text-white"><ArrowLeft size={16} aria-hidden />{t('back')}</Link>
      <header>
        <h1 className="text-3xl font-semibold tracking-tight">{d.title}</h1>
        <p className="mt-1 text-sm text-white/50">{t('updated')}: {LEGAL.updated}</p>
      </header>
      {contactFirst && <Contact />}
      {d.sections.map((s) => (
        <section key={s.h}>
          <h2 className="mb-2 font-semibold">{s.h}</h2>
          {s.p.map((x) => <p key={x} className="mb-2 text-white/70">{x}</p>)}
        </section>
      ))}
      {!contactFirst && <Contact />}
    </article>
  )
}
