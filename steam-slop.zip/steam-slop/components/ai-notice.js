'use client'
import { useState } from 'react'
import { Bot, X } from 'lucide-react'
import { useLang } from '@/lib/i18n'

// Dismissible disclosure layer at the top of every page. The footer keeps a permanent line.
export function AiNotice() {
  const { t } = useLang()
  const [open, setOpen] = useState(true)
  if (!open) return null
  return (
    <div role="note" className="border-b border-white/[0.08] bg-surface">
      <div className="mx-auto flex max-w-5xl items-start gap-3 px-4 py-3 text-sm">
        <Bot size={18} aria-hidden className="mt-0.5 shrink-0 text-accent" />
        <p className="flex-1 text-white/80">{t('ai')}</p>
        <button onClick={() => setOpen(false)} aria-label={t('aiClose')} className="rounded-md p-1 text-white/50 hover:text-white"><X size={16} aria-hidden /></button>
      </div>
    </div>
  )
}
