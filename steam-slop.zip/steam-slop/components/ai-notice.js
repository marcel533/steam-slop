'use client'
import { useEffect, useState } from 'react'
import { Bot } from 'lucide-react'
import { useLang } from '@/lib/i18n'

const KEY = 'ss-ai-notice'

// Small cookie-style disclosure in the bottom-left corner. Once the visitor clicks the button
// the choice is remembered in localStorage, so it does not come back on later visits.
// It starts hidden and is only shown after mount: no hydration mismatch, and no flash for returning visitors.
// The footer keeps a permanent line with the same text.
export function AiNotice() {
  const { t } = useLang()
  const [open, setOpen] = useState(false)

  useEffect(() => {
    let seen = false
    try { seen = localStorage.getItem(KEY) === '1' } catch {}
    if (!seen) setOpen(true)
  }, [])

  const accept = () => {
    setOpen(false)
    try { localStorage.setItem(KEY, '1') } catch {}
  }

  if (!open) return null
  return (
    <div role="note" aria-label="AI disclosure" className="fixed bottom-4 left-4 right-4 z-50 sm:right-auto sm:max-w-xs">
      <div className="rounded-lg border border-white/[0.12] bg-surface p-3 text-xs shadow-lg shadow-black/40">
        <div className="flex items-start gap-2">
          <Bot size={16} aria-hidden className="mt-0.5 shrink-0 text-accent" />
          <p className="text-white/80">{t('ai')}</p>
        </div>
        <button onClick={accept} className="mt-3 w-full rounded-md bg-accent px-3 py-1.5 font-medium text-black hover:opacity-90">{t('aiOk')}</button>
      </div>
    </div>
  )
}
