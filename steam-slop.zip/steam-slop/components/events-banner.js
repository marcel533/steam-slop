'use client'
import { useEffect, useState } from 'react'
import { CalendarDays } from 'lucide-react'
import { SteamButton } from '@/components/brand'
import { useLang } from '@/lib/i18n'
import { EVENTS } from '@/lib/events'

const day = (s) => new Date(`${s}T00:00:00`)

// Rendered after mount only: "today" differs between server and browser.
export function EventsBanner() {
  const { lang, t } = useLang()
  const [now, setNow] = useState(null)
  useEffect(() => { setNow(new Date()) }, [])
  if (!now) return null

  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const live = EVENTS.filter((e) => day(e.start) <= today && today <= day(e.end))
  const next = EVENTS.filter((e) => day(e.start) > today).sort((a, b) => day(a.start) - day(b.start)).slice(0, 2)
  if (!live.length && !next.length) return null
  const fmt = (s) => day(s).toLocaleDateString(lang === 'de' ? 'de-DE' : 'en-US', { month: 'short', day: 'numeric' })

  return (
    <section aria-label={t('events')} className="border-b border-white/[0.08] bg-accent/[0.06]">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3 text-sm">
        <CalendarDays size={16} aria-hidden className="text-accent" />
        {live.map((e) => (
          <p key={e.name + e.start} className="flex items-center gap-2">
            <span className="rounded-md bg-accent px-1.5 py-0.5 text-xs font-semibold uppercase text-black">{t('eventsLive')}</span>
            {e.url ? <a href={e.url} target="_blank" rel="noopener noreferrer" className="font-medium underline">{e.name}</a> : <span className="font-medium">{e.name}</span>}
            <span className="text-white/50">{t('until')} {fmt(e.end)}</span>
          </p>
        ))}
        {next.map((e) => (
          <p key={e.name + e.start} className="flex items-center gap-2 text-white/70">
            <span className="text-white/40">{t('eventsNext')}</span>
            <span>{e.name}</span>
            <span className="text-white/50">{fmt(e.start)} – {fmt(e.end)}</span>
          </p>
        ))}
        <SteamButton href="https://store.steampowered.com/" label={t('steam')} className="ml-auto" />
      </div>
    </section>
  )
}
