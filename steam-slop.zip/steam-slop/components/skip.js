'use client'
import { useLang } from '@/lib/i18n'
export function SkipLink() {
  const { t } = useLang()
  return <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded-md focus:bg-accent focus:px-3 focus:py-2 focus:text-black">{t('skip')}</a>
}
