# Steam Slop
npm install && npm run dev

Data layer: lib/games.js exports searchGames, getGame, getTopSlop. Replace their bodies with
Steam Web API / store endpoints plus your own analysis table. Components do not change.
